import os
import json
import os
from root import RQRoot
import read_excel
import sys

class RQStage(RQRoot):
    def __init__(self,data,stagejson) -> None:
        super().__init__(data,stagejson)
    def recursion_count_layer(self, di_child,dict_count):
        layer_n = 0
        for node in di_child.keys():
            if type(di_child[node]) == list:
                if len(di_child[node]) == 1 and di_child[node][0]['id'] == 0:
                    tmp_count = 0
                else:
                    tmp_count = len(di_child[node])
                layer_n += tmp_count
            else:
                # print("\t", end=" ")
                tmp_count = self.recursion_count_layer(di_child[node], dict_count)
                layer_n += tmp_count
            dict_count.update({node: tmp_count})
        return layer_n

    def mappingTojson_recursion(self, id_url_dic, original_json_dic, di, di_child, recursion_layer):
        for node in original_json_dic:
            if node == 'mapping':
                continue
            di_child[node] = {}
            if type(original_json_dic[node]) == list:
                for each in original_json_dic[node]:
                    di_child[node][each] = []
                    if each in di.keys():
                        for _ in di.pop(each):
                            di_child[node][each].append({'id': _, "url": id_url_dic[_]})
                    else:
                        di_child[node][each].append({'id': 0, "url": None})
            else:
                self.mappingTojson_recursion(id_url_dic, original_json_dic[node], di, di_child[node],
                                             recursion_layer + 1)
        return di_child
    def mappingTojson_recursion_2(self, id_url_dic, original_json_dic, di, di_child_2, recursion_layer,dict_count):
        for node in original_json_dic:
            if node == 'mapping':
                continue
            di_child_2[node] = {}
            for i in range(recursion_layer - 1):
                print('\t', end=' ')
            print(node, ":", dict_count[node], " ")
            if type(original_json_dic[node]) == list:
                for each in original_json_dic[node]:
                    di_child_2[node][each] = []
                    for i in range(recursion_layer):
                        print('\t', end=' ')
                    print('{}'.format(each), end=' ')
                    if each in di.keys():
                        for _ in di.pop(each):
                            di_child_2[node][each].append({'id': _, "url": id_url_dic[_]})
                        print(":{} ".format(len(di_child_2[node][each])))
                    else:
                        print(":0 ".format(node, each))
                        di_child_2[node][each].append({'id': 0, "url": None})
            else:
                self.mappingTojson_recursion_2(id_url_dic, original_json_dic[node], di, di_child_2[node],
                                             recursion_layer + 1,dict_count)
    def printStage(self):
        tree = self.tree.copy()
        mapping_key_value = tree.pop('mapping')
        stage_father_child= tree
        di = {}
        for item in self.data:
            idd = item['DB ID']
            stageName = item['exposing stage']
            if stageName != None:
                stageName = stageName.rstrip(' ').rstrip(' ')
            if not stageName in di:
                di[stageName] = []
            di[stageName].append(idd)
        # Mapping: wild stage normalize
        for key in mapping_key_value:
            if not mapping_key_value[key][0] in di:
                di[mapping_key_value[key][0]] = []
            if key in di.keys():
                for each_value in di.pop(key):
                    di[mapping_key_value[key][0]].append(each_value)
        id_url_dic = {}
        for item in self.data:
            id_url_dic.update({item['DB ID']:item['URL']})
        di_child = {}
        di_2 = di.copy()
        self.mappingTojson_recursion(id_url_dic, stage_father_child, di, di_child, 1)
        dict_count = {}
        self.recursion_count_layer(di_child,dict_count)
        di_child_2 = {}
        self.mappingTojson_recursion_2(id_url_dic, stage_father_child, di_2, di_child_2, 1, dict_count)
        with open('{}.json'.format("stage_id"), 'w') as f:
            json.dump(di_child, f, indent=4)
        for key in di:
            print("{} : {}".format(key,di[key]))
        return di

    def printIntroStage(self):
        tree = self.tree.copy()
        mapping_key_value = tree.pop('mapping')
        stage_father_child= tree
        di = {}
        for item in self.data:
            idd = item['DB ID']
            stageName = item['introducing stage']
            if stageName != None:
                stageName = stageName.rstrip(' ').rstrip(' ')
            if not stageName in di:
                di[stageName] = []
            di[stageName].append(idd)
        # Mapping: wild stage normalize
        for key in mapping_key_value:
            if not mapping_key_value[key][0] in di:
                di[mapping_key_value[key][0]] = []
            if key in di.keys():
                for each_value in di.pop(key):
                    di[mapping_key_value[key][0]].append(each_value)
        id_url_dic = {}
        for item in self.data:
            id_url_dic.update({item['DB ID']:item['URL']})
        di_child = {}
        di_2 = di.copy()
        self.mappingTojson_recursion(id_url_dic, stage_father_child, di, di_child, 1)
        dict_count = {}
        self.recursion_count_layer(di_child,dict_count)
        di_child_2 = {}
        self.mappingTojson_recursion_2(id_url_dic, stage_father_child, di_2, di_child_2, 1, dict_count)
        with open('{}.json'.format("stage2_id"), 'w') as f:
            json.dump(di_child, f, indent=4)
        for key in di:
            print("{} : {}".format(key,di[key]))
        return di