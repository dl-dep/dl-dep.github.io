# -*- coding: utf-8 -*- 
import os
import json
import xlrd
keyList = ['DB ID','URL','symptom','exposing stage', 'exposing dependency', 'root cause', 'introducing stage','introducing dependency','fix','knowledge']

def columns():
    global keyList    
    di = {}
    offset = 0
    for i in range(0,len(keyList)):
        key = keyList[i]
        di[key] = i + offset
    return di

def traverseExcelGetDataStruct(sheet1,cols):
    cursor = 0
    global keyList
    result = []
    for r in sheet1.get_rows():
        if cursor == 0:
            cursor += 1
            continue
        entry = {}
        for key in keyList:
            val = sheet1.cell(cursor,cols[key]).value
            entry[key] = val
        result.append(entry)
        cursor+=1
    return result
   
def startM(xlsPath):
    rw = xlrd.open_workbook(xlsPath)
    sheet1 = rw.sheet_by_index(0)
    cols = columns()
    tableIIDict =  traverseExcelGetDataStruct(sheet1,cols)
    return tableIIDict

