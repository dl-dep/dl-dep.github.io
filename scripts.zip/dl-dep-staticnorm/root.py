import imp
import os
import json



class RQRoot(object):

    def __init__(self,data,taxonomyjson) -> None:
        self.data = data
        self.cnt = 0
        self.tree = self.loadjson(taxonomyjson)
        self.taxonomyleaf = 0

    def printLayer(self,node,depth):
        indent = ''
        for i in range(0,depth):
            indent = indent + '    '
        if type(node) == list:
            for item in node:
                print(indent + item)
                cnt +=1
        if type(node) == dict:
            for key in node:
                print(indent + key)
                self.printLayer(node[key],depth +1)

    def loadjson(self,taxonomyjson):
        with open(taxonomyjson,'r',encoding='utf8',errors='ignore') as f:
            content = ''
            for line in f:
                if line.lstrip(' ').startswith('//'):
                    continue
                content = content + line
            self.taxonomyleaf = self.cnt
            self.cnt = 0
            self.tree = json.loads(content)
        return self.tree
