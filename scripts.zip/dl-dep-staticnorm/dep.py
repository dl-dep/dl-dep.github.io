from cgi import print_arguments
import csv
from ctypes import POINTER
from json.tool import main
import mailbox
import xlrd
import pandas as pd
import json

lib_li = []
str1 = []
trible_dic = {}
double_li = []
trible_li = []

class stack_normalization():
    def stack_name_map(self, stack_name, json_path):
        with open(json_path) as f1:
            done_dic = json.load(f1)
        for key in done_dic.keys():
            if key == "mapping":
                pass
            elif stack_name in done_dic[key]:
                return key, stack_name
        if stack_name in done_dic['mapping']:
            # print(lib_name)
            for key in done_dic.keys():
                if done_dic['mapping'][stack_name][0] in done_dic[key]:
                    return key,  done_dic['mapping'][stack_name][0]
        return None, None
    def lib_name_map(self, lib_name,json_path):
        with open(json_path) as f1:
            done_dic = json.load(f1)
        if lib_name in list(done_dic['mapping'].keys()):
            # print(lib_name)
            for key in done_dic.keys():
                if key != "mapping":
                    if done_dic['mapping'][lib_name][0] in done_dic[key]:
                        return key,  done_dic['mapping'][lib_name][0]
        for key in done_dic.keys():
            if key == "mapping":
                pass
            elif lib_name in done_dic[key]:
                return key, lib_name
        return None, None
    def lib_father_lib_map(self,lib_name):
        with open("sort.json") as f1:
            done_dic = json.load(f1) 
        for key in done_dic.keys():
            if key == "mapping":
                continue
            if lib_name in done_dic[key]:
                return key
        return None
    def not_top_map(self,lib_dic,map_lib_li):
        for each_map_lib in map_lib_li:
            pop_li = []
            for key in lib_dic.keys():
                if each_map_lib[0] in key:
                    map_num = lib_dic[key]
                    mapped_key = key.replace(each_map_lib[0], '\'' + each_map_lib[1]  + '\'')
                    if mapped_key not in lib_dic.keys():
                        lib_dic.update({mapped_key:lib_dic.pop(key)})
                    else:
                        lib_dic[mapped_key] += map_num
                        pop_li.append(key)         
            for each_pop_lib in pop_li:
                lib_dic.pop(each_pop_lib)
    def lib_name_norm(self):
        lib_mapping_dic = self.stack2json()
        double_li = []
        exposing_li = []
        introducing_li = []
        introducing_stage_li = []  
        b = set()

        for id_key in lib_mapping_dic.keys():
            each_error_list = []
            each_root_list  = []
            exposing_stage =  lib_mapping_dic[id_key]["exposing_stage"][0][0]
            introducing_stage =  lib_mapping_dic[id_key]["introducing_stage"][0][0]
            for _ in lib_mapping_dic[id_key]["error_lib"]:
                each_error_list.append(_)
            
            for _ in lib_mapping_dic[id_key]["root_lib"]:
                each_root_list.append(_)
            error_lib_num = len(each_error_list)
            root_lib_num  = len(each_root_list)
            if error_lib_num > 1:
                print("many-error_lib {}----{}".format(each_error_list,each_root_list))
                continue
            if error_lib_num == 0 or root_lib_num == 0:
                 print("{}----{}".format(each_error_list,each_root_list))
                 continue
            each_error_list = each_error_list * root_lib_num
            for i in range(0, max(error_lib_num,root_lib_num)):
                if "cuDNN" in each_root_list[i]:
                    b.add(id_key)
                double_li.append([each_error_list[i], each_root_list[i]])
                introducing_li.append([each_root_list[i],introducing_stage])
            introducing_stage_li.append([each_error_list[i],introducing_stage])
            exposing_li.append([each_error_list[i],exposing_stage])
        sankey_lib = ["Keras", "Application", "TensorFlow", "PyTorch", "Other Libraries", "Runtime", "cuDNN", "CUDA", "Other Drivers", "OS/Container", "Hardware"]
        li_name  = ['source', 'target', 'value']
        trible_di = {}
        trible_li = []
        i = 0
        for each_lib_tuple in double_li:
            if each_lib_tuple[0][1].rstrip() not in sankey_lib and each_lib_tuple[0][0] == "Library":
                # print("exposing:", each_lib_tuple[0][1])
                each_lib_tuple[0][1] = "Other Libraries"
            if each_lib_tuple[1][1].rstrip() not in sankey_lib and each_lib_tuple[1][0] == "Library":
                # print("introducing:", each_lib_tuple[1][1])
                each_lib_tuple[1][1] = "Other Libraries"
            if each_lib_tuple[0][1].endswith("  "): pass
            else: each_lib_tuple[0][1] = each_lib_tuple[0][1] + "  "
            if each_lib_tuple[1][1].endswith("  "): pass
            else:   each_lib_tuple[1][1] = each_lib_tuple[1][1] +  " "
            i += 1 
            if each_lib_tuple[0][1] + "," + each_lib_tuple[1][1] not in trible_di.keys():
                trible_di[each_lib_tuple[0][1] + "," + each_lib_tuple[1][1]] = 1
            else:
                trible_di[each_lib_tuple[0][1] + "," + each_lib_tuple[1][1]] += 1
        for each_key in trible_di.keys():
            trible_li.append([each_key.split(",")[0], each_key.split(",")[1], trible_di[each_key]])
        test = pd.DataFrame(columns=li_name, data=trible_li)
        # test.to_csv('map_lib.csv')
        
        trible_di = {}
        trible_li = []
        root_count_dic ={}
        introducing_stage_count_dic ={}
        # print(introducing_li)
        for each_introducing_tuple in introducing_li:
            # if each_introducing_tuple[0][1].rstrip() not in sankey_lib and each_introducing_tuple[0][0] == "Library":
            #     each_introducing_tuple[0][1] = "Other Libraries"
            if each_introducing_tuple[0][1].endswith("  "): pass
            else: each_introducing_tuple[0][1] = each_introducing_tuple[0][1] + " "
            if each_introducing_tuple[1].endswith(" "): pass
            else: each_introducing_tuple[1] = each_introducing_tuple[1] + " "
            if each_introducing_tuple[0][1] + "," + each_introducing_tuple[1] not in trible_di.keys():
                trible_di[each_introducing_tuple[0][1] + "," + each_introducing_tuple[1]] = 1
            else:
                trible_di[each_introducing_tuple[0][1] + "," + each_introducing_tuple[1]] += 1
        for each_key in trible_di.keys():
            if each_key.split(",")[0] not in root_count_dic.keys():
                root_count_dic[each_key.split(",")[0]] = trible_di[each_key]
            else:
                root_count_dic[each_key.split(",")[0]] += trible_di[each_key]
            # if each_key.split(",")[1] not in introducing_stage_count_dic.keys():
            #     introducing_stage_count_dic[each_key.split(",")[1]] = trible_di[each_key]
            # else:
            #     introducing_stage_count_dic[each_key.split(",")[1]] += trible_di[each_key]
            trible_li.append([each_key.split(",")[0], each_key.split(",")[1], trible_di[each_key]])
        print("-------------intruducing lib-------------")
        for each_key in root_count_dic.keys():
            print(each_key, ": ", root_count_dic[each_key])
        print("-------------introducing stage-------------")
        for each_lib_mapping_key in lib_mapping_dic.keys():
            father_intro_stage = lib_mapping_dic[each_lib_mapping_key]['introducing_stage'][0][0]
            if father_intro_stage not in introducing_stage_count_dic.keys():
                introducing_stage_count_dic[father_intro_stage] = 1
            else:
                introducing_stage_count_dic[father_intro_stage] += 1
        for each_key in introducing_stage_count_dic.keys():
            print(each_key, ": ", introducing_stage_count_dic[each_key])    
        for each in trible_li:
            each[1] = each[1].title()
        test = pd.DataFrame(columns=li_name, data=trible_li)
        test.to_csv('introducing.csv')
        
        error_count_dic = {}
        exposing_stage_count_dic ={}
        trible_di = {}
        trible_li = []
        # print(exposing_li)
        for each_exposing_tuple in exposing_li:
            if each_exposing_tuple[0][1].rstrip() not in sankey_lib and each_exposing_tuple[0][0] == "Library":
                each_exposing_tuple[0][1] = "Other Libraries"
            if each_exposing_tuple[0][1].endswith("  "): pass
            else: each_exposing_tuple[0][1] = each_exposing_tuple[0][1] + " "
            
            if each_exposing_tuple[1].endswith(" "): pass
            else: each_exposing_tuple[1] = each_exposing_tuple[1] + " "
            
            if each_exposing_tuple[0][1] + "," + each_exposing_tuple[1] not in trible_di.keys():
                trible_di[each_exposing_tuple[0][1] + "," + each_exposing_tuple[1]] = 1
            else:
                trible_di[each_exposing_tuple[0][1] + "," + each_exposing_tuple[1]] += 1
        for each_key in trible_di.keys():
            if each_key.split(",")[0] not in error_count_dic.keys():
                error_count_dic[each_key.split(",")[0]] = trible_di[each_key]
            else:
                error_count_dic[each_key.split(",")[0]] += trible_di[each_key]
            if each_key.split(",")[1] not in exposing_stage_count_dic.keys():
                exposing_stage_count_dic[each_key.split(",")[1]] = trible_di[each_key]
            else:
                exposing_stage_count_dic[each_key.split(",")[1]] += trible_di[each_key]
            trible_li.append([each_key.split(",")[0], each_key.split(",")[1], trible_di[each_key]])
        print("---------exposing lib------------")
        for each_key in error_count_dic.keys():
            print(each_key, ": ", error_count_dic[each_key])
        print("---------exposing stage------------")
        for each_key in exposing_stage_count_dic.keys():
            print(each_key, ": ", exposing_stage_count_dic[each_key])
        for each_tuple in trible_li:
            each_tuple[1] = each_tuple[1].title()
        test = pd.DataFrame(columns=li_name, data=trible_li)
        test.to_csv('exposing.csv')



    def stack2json(self):
        lib_map_path = 'taxonomy_lib.json'
        book = xlrd.open_workbook('dataset.xls')
        names = book.sheet_names()
        sheet = book.sheet_by_name(names[0])
        rows = sheet.nrows
        error_count_dic = {}
        root_count_dic = {}
        stack2jison_dic = {}
        for i in range(1,rows):
            each_error_list = []
            each_root_list  = []
            id = sheet.cell_value(i,0)
            stack2jison_dic[id] = {}
            stack2jison_dic[id]["id"] = id
            stack2jison_dic[id]["error_lib"] = []
            stack2jison_dic[id]["root_lib"] = []
            stack2jison_dic[id]["exposing_stage"] = []
            stack2jison_dic[id]["introducing_stage"] = []
            for each in sheet.cell_value(i,4).split('\n'):
                layer, lib_name = self.lib_name_map(each,lib_map_path)
                if lib_name != None:
                    # print(self.lib_name_map(each))
                    each_error_list.append(lib_name)
                    stack2jison_dic[id]["error_lib"].append([layer, lib_name])
                else:
                    print(id, ":", each)
            for each in sheet.cell_value(i,7).split(', '):    
                layer, lib_name = self.lib_name_map(each,lib_map_path)
                if lib_name != None:
                    # print(self.lib_name_map(each))
                    each_root_list.append(self.lib_name_map(each,lib_map_path))
                    stack2jison_dic[id]["root_lib"].append([layer, lib_name])
                else:
                    print(id, ":", each)
            stage_map_path = 'taxonomy_stage.json'
            for each in sheet.cell_value(i,3).split('\n'):    
                layer, lib_name = self.stack_name_map(each,stage_map_path)
                if lib_name != None:
                    # print(self.lib_name_map(each))
                    each_root_list.append(self.stack_name_map(each,stage_map_path))
                    stack2jison_dic[id]["exposing_stage"].append([layer, lib_name])
                else:
                    print(id, ":", each)
            for each in sheet.cell_value(i,6).split('\n'):  
                layer, lib_name = self.stack_name_map(each,stage_map_path)
                if lib_name != None:
                    # print(self.lib_name_map(each))
                    each_root_list.append(self.stack_name_map(each,stage_map_path))
                    stack2jison_dic[id]["introducing_stage"].append([layer, lib_name])
                else:
                    print(id, ":", each)
            error_lib_num = len(each_error_list)
            root_lib_num  = len(each_root_list)
            for each_error_lib in each_error_list:
                if each_error_lib not in error_count_dic.keys():
                    error_count_dic[each_error_lib] = 1
                else:
                    error_count_dic[each_error_lib] += 1
            for each_root_lib in each_root_list:
                if each_root_lib not in root_count_dic.keys():
                    root_count_dic[each_root_lib] = 1
                else:
                    root_count_dic[each_root_lib] += 1
        return stack2jison_dic
if __name__=="__main__":
    # erase the hardware and application
    stack_norm = stack_normalization()
    stack_norm.lib_name_norm()