from itertools import count
import os
import re
import json
from root import RQRoot
import read_excel
import sys

class RQFix(RQRoot):
    def __init__(self,data,stagejson) -> None:
        super().__init__(data,stagejson)
    def recursion_flatten(self, dic1, flatten_li):
        for node in dic1:
            if type(dic1[node]) == list:
                for each in dic1[node]:
                    flatten_li.append(each)
            else:
                self.recursion_flatten(dic1[node], flatten_li)
    def id2root(self, root_list_id):
        with open("root_id.json",'r') as f1:
            dic1 = json.load(f1)
        flatten_li = []
        self.recursion_flatten(dic1,flatten_li)
        for each in flatten_li:
            if root_list_id == each['id']:
                return [each['root'],each['id']]
    def recursion_count_layer(self, di_child,dict_count, mode):
        layer_n = 0
        for node in di_child.keys():
            if type(di_child[node]) == list:
                if len(di_child[node]) == 1 and di_child[node][0]['id'] == 0:
                    tmp_count = 0
                else:
                    counted_id_list = []
                    for each_child_node in di_child[node]:
                        if mode == 'knowledge':
                            if each_child_node['id']['id'] not in counted_id_list:
                                counted_id_list.append(each_child_node['id']['id'])
                        elif mode == 'fix':
                            if each_child_node['id'] not in counted_id_list:
                                counted_id_list.append(each_child_node['id'])
                    tmp_count = len(counted_id_list)
                layer_n += tmp_count
            else:
                tmp_count = self.recursion_count_layer(di_child[node], dict_count, mode)
                layer_n += tmp_count
            dict_count.update({node: tmp_count})
        return layer_n
    def recursion_print(self,di_child):
        for node in di_child:
            knowledge_list = []
            if type(di_child[node]) == list:
                for each_knowledge in di_child[node]:
                    if each_knowledge['id'] != 0:
                        if len(each_knowledge['id']['url2']) > 0 and each_knowledge['id']['url2'] != None:
                            print(node,"-", each_knowledge['id']['id'], end=" ")
                            for every_url2 in each_knowledge['id']['url2']:
                                if every_url2 not in knowledge_list:
                                    print(":",every_url2)
                            print(" ")
                            for _ in each_knowledge['id']['url2']: knowledge_list.append(_)
                    else:
                        print(node, ":", "None")
            else:
                self.recursion_print(di_child[node])
    def mappingTojson_fix_recursion(self, original_json_dic, di, di_child, recursion_layer):
        for node in original_json_dic:
            if node == 'mapping':
                continue
            di_child[node] = {}
            if type(original_json_dic[node]) == list:
                for each in original_json_dic[node]:
                    di_child[node][each] = []
                    for each_rq in di:
                        if each in each_rq.keys():
                            print("-----------")
                            print(each_rq)
                            di_child[node][each].append({'id': each_rq['DB ID'], "url": each_rq['URL'], each: each_rq.pop(each)})
                        del_index = []
                        for each_pending_index in range(len(each_rq['pending'])):
                            if each == each_rq['pending'][each_pending_index].split('----')[0]:
                                di_child[node][each].append({'id': each_rq['DB ID'], "url": each_rq['URL'], each: each_rq['pending'][each_pending_index]})
                                del_index.append(each_pending_index)
                            if each_rq['pending'][each_pending_index] =='':
                                del_index.append(each_pending_index)
                        del_index.reverse()
                        if del_index != None:
                            for each_del in del_index:
                             each_rq['pending'].pop(each_del)
            else:
                self.mappingTojson_fix_recursion(original_json_dic[node], di, di_child[node], recursion_layer + 1)
    def mappingTojson_fix_recursion_2(self, original_json_dic, recursion_layer, dict_count,di_child, on_off):
        for node in original_json_dic:
            if node == 'mapping':
                continue
            for i in range(recursion_layer - 1):
                print('\t', end=' ')
            if node == "Change Dependency Version":
                print(node, ":", self.printFix2(), " ")
            elif node == "Change Dependency":
                print(node, ":", dict_count[node] + self.printFix2() - dict_count["Change Dependency Version"], " ")
            else:
                print(node, ":", dict_count[node], " ")
            if type(original_json_dic[node]) == list:
                for each in original_json_dic[node]:
                    root_list = []
                    root_list_id =[]
                    root_dict = {}
                    for i in range(recursion_layer):
                        print('\t', end=' ')
                    print('{}'.format(each), end=' ')
                    print(":{} ".format(len(di_child[node][each])))
                    if on_off == "on":
                        for each_id in di_child[node][each]:
                            root_list_id.append(each_id["id"])
                        for each_id in root_list_id:
                            if self.id2root(each_id)[0] not in root_list:
                                root_list.append(self.id2root(each_id)[0])
                                root_dict[self.id2root(each_id)[0]] = [self.id2root(each_id)[1]]
                            else:
                                root_dict[self.id2root(each_id)[0]].append(self.id2root(each_id)[1])
                        root_dict = dict(sorted(root_dict.items(), key = lambda kv:(len(kv[1]), kv[0]),reverse=True))
                        for key in root_dict.keys():
                            for i in range(recursion_layer + 1):
                                print("\t",end=' ')
                            print("{}:{} ".format(key,root_dict[key]))
            else:
                self.mappingTojson_fix_recursion_2(original_json_dic[node], recursion_layer + 1, dict_count,di_child[node], on_off)
    def printFix(self, on_off):
        tree = self.tree
        stage_father_child = tree.copy()
        mapping_key_value = tree.pop('mapping')
        # key of the item: id url fix   up down del add pending
        or_num = 0
        and_num = 0
        all_fix_num = 0
        for item in self.data:
            idd = item['DB ID']
            fix = item['fix']
            url = item['URL']
            item['pending'] = []
            if fix != None:
                fix = fix.rstrip(' ').rstrip(' ').rstrip('\n')
            and_num += 1
            and_num += fix.count("\n",0,len(fix))
            or_num += fix.count("\nor",0,len(fix))
            and_num -= fix.count("\nor",0,len(fix))

            for each in fix.replace("or ", "").lstrip(' ').split('\n'):
                if each not in item.keys():
                    if ":" in each:
                        if "upgrade" in each:
                            item['pending'].append("Upgrade Version")
                        if "unknown version change" in each:
                            item['pending'].append("Upgrade Version")
                        if "downgrade" in each:
                            item['pending'].append("Downgrade Version")
                        # for i in range(each.count("downgrade"), each.count("downgrade")):
                        #     item['pending'].append("Downgrade Version")
                        for i in range(0, each.count("Add Dependency")):
                            item['pending'].append("Add Dependency")
                        for i in range(0, each.count("Remove Dependency")):
                            item['pending'].append("Remove Dependency")
                        # if "unknown version change" in each:
                        #     item['pending'].append("Unknown Version Change")
                        # for i in range(0, each.count("unknown version change")):
                        #     item['pending'].append("Unknown Version Change")
                    elif "Unknown Version Change" in each:
                        item['pending'].append("Unknown Version Change")
                    else:
                        item['pending'].append(each)
        di = self.data.copy()     
        # Mapping: mode to node
        for key in mapping_key_value:
            for each_id in di:
                for each_pending in each_id['pending']:
                    if key == each_pending.split('----')[0]:
                        each_id['pending'][each_id['pending'].index(each_pending)] = each_id['pending'][each_id['pending'].index(each_pending)].replace(each_pending.split('----')[0],mapping_key_value[key][0])
        di_child = {}
        self.mappingTojson_fix_recursion(stage_father_child, di, di_child, 1)
        dict_count = {}
        self.recursion_count_layer(di_child,dict_count,"fix")
        with open('{}.json'.format("fix_id"), 'w') as f:
            json.dump(di_child, f, indent=4)
        self.mappingTojson_fix_recursion_2(stage_father_child, 1, dict_count,di_child, on_off)
        for each in di:
            if 'pending' in each.keys():
                if len(each['pending']) > 0:
                    print(each['DB ID'],each['URL'],each['pending'])
    def recursion_flatten1(self, dic1,flatten_li):
        if type(dic1) == list:
            for node in dic1:
                if node['id'] != 0.0 and node['id'] not in flatten_li:
                    flatten_li.append(node['id'])
        else:
            for key in dic1.keys():
                self.recursion_flatten1(dic1[key], flatten_li)
    def fix_flaten(self, dic1):
        flatten_li = []
        self.recursion_flatten1(dic1, flatten_li)
        return flatten_li
    def printFix2(self):
        with open("fix_id.json","r") as fr:
            dic1 = json.load(fr)    
        Fix_1st_L ={}
        for each_key in dic1.keys():
            if each_key != 'qa answer' and each_key != 'other':
                for each_child_key in dic1[each_key].keys():
                    Fix_1st_L[each_child_key] = self.fix_flaten(dic1[each_key][each_child_key])
        Change_Dependency_Version = len(set(Fix_1st_L['Change Dependency Version']))
        return Change_Dependency_Version