
import re


def is_valid_version(version):
    """
        this method checks whether a given word is of a semantic version string.
        e.g., 1.2.3-snapshot.
    """
    if '.' not in version:
        return False
    data = version.split('.') # split the semantic version number into sub version numbers.
    pat = re.compile('^[0-9]+$')
    pat2 = re.compile('^[0-9]+[a-zA-Z\-]*$')
    if pat.match(data[0]) == None:
        # not a valid major version
        return
    if len(data) == 2:
        if pat2.match(data[1]) == None:
            # not a valid minor version
            return False
        else:
            # version pattern: major.minor
            return True
    if len(data) >= 3:
        if pat2.match(data[-1]) == None:
            # not a valid minor version
            return False
        else:
            # check the rest 
            flag = True
            for i in range(1, len(data)-1):
                if pat.match(data[i]) == None:
                    # not a valid version
                    flag = False
                if flag == False:
                    break
            if flag:
                # valid version
                return True
            
