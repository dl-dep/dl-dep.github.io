from itertools import count
import os
import re
import json
from root import RQRoot
import read_excel
import sys
addition_num = 0
pending_num = 0
class RQKnowledge(RQRoot):
    def __init__(self,data,stagejson) -> None:
        super().__init__(data,stagejson)
    def recursion_flatten(self, dic1, flatten_li):
        for node in dic1:
            if type(dic1[node]) == list:
                for each in dic1[node]:
                    flatten_li.append(each)
            else:
                self.recursion_flatten(dic1[node], flatten_li)
    def id2root(self, root_list_id):
        with open("root_id.json",'r') as f1:
            dic1 = json.load(f1)
        flatten_li = []
        self.recursion_flatten(dic1,flatten_li)
        for each in flatten_li:
            if root_list_id == each['id']:
                return [each['root'],each['id']]
    def recursion_count_layer(self, di_child,dict_count, mode):
        layer_n = 0
        for node in di_child.keys():
            if type(di_child[node]) == list:
                if len(di_child[node]) == 1 and di_child[node][0]['id'] == 0:
                    tmp_count = 0
                else:
                    counted_id_list = []
                    for each_child_node in di_child[node]:
                        if mode == 'knowledge':
                            if each_child_node['id']['id'] not in counted_id_list:
                                counted_id_list.append(each_child_node['id']['id'])
                        elif mode == 'fix':
                            if each_child_node['id'] not in counted_id_list:
                                counted_id_list.append(each_child_node['id'])
                    tmp_count = len(counted_id_list)
                layer_n += tmp_count
            else:
                tmp_count = self.recursion_count_layer(di_child[node], dict_count, mode)
                layer_n += tmp_count
            dict_count.update({node: tmp_count})
        return layer_n
    def mappingTojson_knowledge_recursion(self, id_url_dic, original_json_dic, di, di_child, recursion_layer):
        for node in original_json_dic:
            if node == 'mapping':
                continue
            di_child[node] = {}
            if type(original_json_dic[node]) == list:
                for each in original_json_dic[node]:
                    if each in di.keys():
                        di_child[node][each] = []
                        for _ in di.pop(each):
                            di_child[node][each].append({'id': _, "url": id_url_dic[_['id']]})                        
                    else:
                        di_child[node][each] = []
                        di_child[node][each].append({'id': 0, "url": None})
            else:
                self.mappingTojson_knowledge_recursion(id_url_dic, original_json_dic[node], di, di_child[node],
                                             recursion_layer + 1)
    def mappingTojson_knowledge_recursion_2(self, id_url_dic, original_json_dic, di_2, di_child_2, recursion_layer, dict_count):
        for node in original_json_dic:
            if node == 'mapping':
                continue
            di_child_2[node] = {}
            for i in range(recursion_layer - 1):
                print('\t', end=' ')
            print(node, ":", dict_count[node], " ")
            if type(original_json_dic[node]) == list:
                for each in original_json_dic[node]:
                    di_child_2[node][each] = []
                    for i in range(recursion_layer):
                        print('\t', end=' ')
                    print('{}'.format(each), end=' ')
                    if each in di_2.keys():
                        for _ in di_2.pop(each):
                            di_child_2[node][each].append({'id': _, "url": id_url_dic[_['id']]})      
                        counted_li = []
                        for each_di_child_2 in di_child_2[node][each]:
                            if each_di_child_2['id']['id'] not in counted_li:
                                counted_li.append(each_di_child_2['id']['id'])
                        print(":{} ".format(len(counted_li)))
                    else:
                        print(":0 ".format(node, each))
                        di_child_2[node][each].append({'id': 0, "url": None})
            else:
                self.mappingTojson_knowledge_recursion_2(id_url_dic, original_json_dic[node], di_2, di_child_2[node],
                                             recursion_layer + 1, dict_count)
    def recursion_print(self,di_child):
        for node in di_child:
            knowledge_list = []
            if type(di_child[node]) == list:
                for each_knowledge in di_child[node]:
                    if each_knowledge['id'] != 0:
                        if len(each_knowledge['id']['url2']) > 0 and each_knowledge['id']['url2'] != None:
                            print(node,"-", each_knowledge['id']['id'], end=" ")
                            for every_url2 in each_knowledge['id']['url2']:
                                if every_url2 not in knowledge_list:
                                    print(":",every_url2)
                            print(" ")
                            for _ in each_knowledge['id']['url2']: knowledge_list.append(_)
                    else:
                        print(node, ":", "None")
            else:
                self.recursion_print(di_child[node])
    def recursion_flatten1(self, dic1,flatten_li):
        if type(dic1) == list:
            for node in dic1:
                if node['id'] != 0.0 and node['id'] not in flatten_li:
                    flatten_li.append(node['id'])
        else:
            for key in dic1.keys():
                self.recursion_flatten1(dic1[key], flatten_li)
    def fix_flaten(self, dic1):
        flatten_li = []
        self.recursion_flatten1(dic1, flatten_li)
        return flatten_li
    def printKnowledge(self):
        tree = self.tree
        stage_father_child = tree.copy()
        mapping_key_value = tree.pop('mapping')
        di = {}
        for item in self.data:
            idd = item['DB ID']
            url1 = item['URL']
            knowledge = item['knowledge']
            if knowledge != None:
                knowledge = knowledge.rstrip(' ').rstrip(' ').rstrip('\n')
                pattern = re.compile(r'(\()(.*)(\))')
                knowledge = pattern.sub(r'',knowledge)
            if '\n' in knowledge:
                knowledge_list = knowledge.split('\n')            
            if '\n' in knowledge:
                knowledge_list = knowledge.split('\n')
            if "," in knowledge:
                knowledge_list = knowledge.split(', ')
            else:
                knowledge_list = [knowledge]
            for each_knowledge in knowledge_list:
                urls = []
                knowledge_name = ""
                knowledge_link = ""
                if '----' in each_knowledge:
                    kk = each_knowledge.split('----')
                    for i in range(1,len(kk)):
                        if kk[i].startswith('http'):
                            urls.append(kk[i])
                    knowledge_name =kk[0]
                    knowledge_link =kk[1]
                elif each_knowledge.startswith('http'):
                    kk = each_knowledge.split('----')
                    for i in range(0,knowledge_list.index(each_knowledge)):
                        if  '----' in knowledge_list[knowledge_list.index(each_knowledge) - i - 1]:
                            kk.insert(0,knowledge_list[knowledge_list.index(each_knowledge) - i - 1].split('----')[0])
                            break
                    for i in range(1,len(kk)):
                        if kk[i].startswith('http'):
                            urls.append(kk[i])
                    knowledge_name = kk[0]
                    knowledge_link =kk[1]
                else:
                    knowledge_name = each_knowledge
                if not knowledge_name in di:
                    di[knowledge_name] = []
                entry = {}
                entry['id'] = idd
                entry['url2'] = urls
                entry['url'] = url1
                di[knowledge_name].append(entry)
        for key in mapping_key_value:
            if key in di.keys():
                for each_value in di.pop(key):
                    if not mapping_key_value[key][0] in di:
                        di[mapping_key_value[key][0]] = []
                    di[mapping_key_value[key][0]].append(each_value)
        id_url_dic = {}
        for item in self.data:
            id_url_dic.update({item['DB ID']:item['URL']})
        di_child = {}
        di_2 = di.copy()
        classificagtion = ""
        self.mappingTojson_knowledge_recursion(id_url_dic, stage_father_child, di, di_child, 1)
        dict_count = {}
        self.recursion_count_layer(di_child,dict_count, "knowledge")
        di_child_2 = {}
        self.mappingTojson_knowledge_recursion_2(id_url_dic, stage_father_child, di_2, di_child_2, 1, dict_count)
        with open('{}.json'.format("knowledge_id"), 'w') as f:
            json.dump(di_child, f, indent=4)
        isFirst = True
        for key in di:
            print(key)
            print('-----')
            for en in di[key]:
                print(en)
        return di