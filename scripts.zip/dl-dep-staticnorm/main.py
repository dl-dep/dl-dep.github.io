from symptoms import RQError
from fix import RQFix
from stage import RQStage
from knowledge import RQKnowledge
from root_cause import RQRootCause
import read_excel
import sys
import os
from dep import stack_normalization


def main(mode, on_off):
    if os.name == 'nt' or os.name == "posix":
        rootPath = ''

    data = read_excel.startM('dataset.xls')
    errorJson = rootPath  + 'taxonomy_symptoms.json'
    stageJson = rootPath + 'taxonomy_stage.json'
    rootCauseJson = rootPath + 'taxonomy_root cause.json'
    fixJson = rootPath  + 'taxonomy_fix.json'
    knowledgeJson = rootPath + 'taxonomy_knowledge.json'
    if mode == 'symptom':
        rqError = RQError(data, errorJson)
        rqError.printError()
    elif mode == 'stage':
        rqError = RQStage(data, stageJson)
        rqError.printStage()
    elif mode == 'stage2':
        rqError = RQStage(data, stageJson)
        rqError.printIntroStage()
    elif mode == 'root':
        rqRootCause = RQRootCause(data,rootCauseJson)
        rqRootCause.printRootCause(on_off)
    elif mode == 'fix':
        rqFix = RQFix(data, fixJson)
        rqFix.printFix(on_off)
    elif mode == 'knowledge':
        rqKnowledge = RQKnowledge(data, knowledgeJson)
        rqKnowledge.printKnowledge()
    elif mode == 'dep':
        stack_norm = stack_normalization()
        stack_norm.lib_name_norm()
# error, stage, root, fix, knowledge
if __name__ == '__main__':
    arg0 = sys.argv[1]
    arg1 = sys.argv[2]
    main(arg0, arg1)