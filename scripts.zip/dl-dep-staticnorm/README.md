
## Readme

Given input as ``dataset.xls``,  the scripts in this package are used to generate statistical results reported in our paper.

### 1. Prerequisites

* Python 3.*
* Requirements:

```
pip install -r requirements.txt
```

### 2. Taxonomy and Distribution of DBs w.r.t symptom, root cause, fix, exposing stage, introduce stage, knowledge

```
# symptom of DBs:
python main.py symptom off
# root cause of DBs:
python main.py root cause off
# fix of DBs:
python main.py fix off
# exposing stage of DBs:
python main.py stage off
# introducing stage of DBs:
python main.py stage2 off
# knowledge of DBs:
python main.py knowledge off

```

### 3. Sankey Diagrams

The sankey diagrams are generated based on an online [tool](https://observablehq.com). Each node in sankey diagrams is labeled with the dependency name and dependency count. The dependency count could be retrieved from ``python main.py dep off``.

#### Exposing dependencies and introducing dependencies data:
```
python main.py dep off
```
#### Sankey diagram generation:

* ``Exposing dependency vs exposing stage`` is generated [here](https://observablehq.com/@f47add47c5b2604b/edes) using ``exposing.csv``.
* `` Introducing dependency vs introducing stage`` is generated [here](https://observablehq.com/d/858f691d038661ca) using ``introducing.csv``.